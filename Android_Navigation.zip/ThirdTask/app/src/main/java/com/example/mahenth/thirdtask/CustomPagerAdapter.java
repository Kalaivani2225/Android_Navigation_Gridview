package com.example.mahenth.thirdtask;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import android.widget.RelativeLayout;

import java.util.List;

public class CustomPagerAdapter extends PagerAdapter {

    int[] image;

    LayoutInflater inflater;
    Context context;


    public CustomPagerAdapter(Context context, int[] img) {
         this.context=context;
        this.image = img;
    }

    @Override
    public int getCount()
    {
        return image.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == ((RelativeLayout)object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        ImageView img;
        inflater = (LayoutInflater) context.getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View itemview = inflater.inflate(R.layout.list_itemview, container, false);
        img = (ImageView) itemview.findViewById(R.id.img1);
          img.setImageResource(image[position]);

        ((ViewPager) container).addView(itemview);
        return itemview;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {

       container.invalidate();
        }


}
