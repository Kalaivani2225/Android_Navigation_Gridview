package com.example.mahenth.thirdtask;

public class DataObject {

    int image;

    public DataObject(int image)
    {
        this.image=image;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
