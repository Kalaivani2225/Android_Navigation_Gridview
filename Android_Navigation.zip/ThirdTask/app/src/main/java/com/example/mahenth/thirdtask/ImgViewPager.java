package com.example.mahenth.thirdtask;


import android.annotation.TargetApi;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;




/**
 * A simple {@link Fragment} subclass.
 */
public class ImgViewPager extends Fragment {

    ViewPager viewpager;
    CustomPagerAdapter adapter;
    int[] img;

    private static int currentPage = 0;
    private static int NUM_PAGES = 0;
    //int currentPage = 0;
    Timer timer;
    final long DELAY_MS = 500;
    final long PERIOD_MS = 3000;



    public ImgViewPager() {
    }


    @TargetApi(Build.VERSION_CODES.O)
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("ViewPager");
        View view = inflater.inflate(R.layout.fragment_img_view_pager, container, false);

        img = new int[]{R.drawable.img14,
                R.drawable.img15, R.drawable.img16, R.drawable.img17, R.drawable.img19, R.drawable.img23, R.drawable.img24, R.drawable.img25, R.drawable.img26, R.drawable.img27};      //select the image from res/drawable  folder

        viewpager = (ViewPager) view.findViewById(R.id.pager);

        final RadioGroup radioGroup = (RadioGroup) view.findViewById(R.id.radiogroup);


        adapter = new CustomPagerAdapter(getContext(), img);
        viewpager.setAdapter(adapter);


        //CircleIndicator indicator = (CircleIndicator)view.findViewById(R.id.indicator);
        //indicator.setViewPager(viewpager);

        viewpager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {


                currentPage = position;
                switch (currentPage) {
                    case 0:
                        radioGroup.check(R.id.radioButton);
                        break;
                    case 1:
                        radioGroup.check(R.id.radioButton2);
                        break;
                    case 2:
                        radioGroup.check(R.id.radioButton3);
                        break;

                    case 3:
                        radioGroup.check(R.id.radioButton4);
                        break;
                    case 4:
                        radioGroup.check(R.id.radioButton5);
                        break;
                    case 5:
                        radioGroup.check(R.id.radioButton6);
                        break;

                    case 6:
                        radioGroup.check(R.id.radioButton7);
                        break;
                    case 7:
                        radioGroup.check(R.id.radioButton8);
                        break;
                    case 8:
                        radioGroup.check(R.id.radioButton9);
                        break;

                    case 9:
                        radioGroup.check(R.id.radioButton10);
                        break;


                }

            }

            @Override
            public void onPageScrollStateChanged(int state) {


            }

        });

//        Timer timer = new Timer();
        //      timer.scheduleAtFixedRate(new ImgViewPager.PcsTimerTask(), 2800, 3080);

        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == NUM_PAGES - 1) {
                    currentPage = 0;
                }
                viewpager.setCurrentItem(currentPage++, true);
            }
        };

        timer = new Timer(); // This will create a new Thread
        timer.schedule(new TimerTask() { // task to be scheduled

            @Override
            public void run() {
                handler.post(Update);
            }
        }, DELAY_MS, PERIOD_MS);

        return view;
    }
}


    //private class PcsTimerTask extends TimerTask {
      //  @Override
       // public void run() {

         //   getActivity().runOnUiThread(new Runnable() {

           //     @Override
             //   public void run() {
               //     if (viewpager.getCurrentItem() == 0) {
                 //       viewpager.setCurrentItem(1);
                   // } else if (viewpager.getCurrentItem() == 1) {
                     //   viewpager.setCurrentItem(2);
                    //} else if (viewpager.getCurrentItem() == 2) {
                      //  viewpager.setCurrentItem(3);
                    //} else if (viewpager.getCurrentItem() == 3) {
                      //  viewpager.setCurrentItem(4);
                    //} else if (viewpager.getCurrentItem() == 4) {
                      //  viewpager.setCurrentItem(5);
                    //} else if (viewpager.getCurrentItem() == 5) {
                      //  viewpager.setCurrentItem(6);
                    //} else if (viewpager.getCurrentItem() == 6) {
                     //   viewpager.setCurrentItem(7);
                    //} else if (viewpager.getCurrentItem() == 7) {
                      //  viewpager.setCurrentItem(8);
                    //} else if (viewpager.getCurrentItem() == 8) {
                      //  viewpager.setCurrentItem(9);
                    //} else if (viewpager.getCurrentItem() == 9) {
                      //  viewpager.setCurrentItem(10);
                    //} else {
                      //  viewpager.setCurrentItem(1);
                   // }

                //}
            //});

        //}
    //}
