package com.example.mahenth.thirdtask;

import java.util.ArrayList;

public class DataSource {

    public static ArrayList<Information> getData()
    {
        ArrayList<Information> data = new ArrayList<>();

        int[] images = {
                R.drawable.img,
                R.drawable.img1,
                R.drawable.img2,
                R.drawable.img3,
                R.drawable.img4,
                R.drawable.img5,
                R.drawable.img6,
                R.drawable.img7,
                R.drawable.img8,
                R.drawable.img9,
                R.drawable.img10,

        };


        String[] Categories={"Picture 1","Picture 2","Picture 3","Picture 4","Picture 5",
                "Picture 6","Picture 7","Picture 8","Picture 9","Picture 10","Picture 11"};


        for(int i=0; i<images.length; i++) {
            Information current = new Information();
            current.title = Categories[i];
            current.imageId = images[i];

            data.add(current);

        }
        return data;


        }
    }
