package com.example.mahenth.thirdtask;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CustomAdapter extends PagerAdapter {
    private  int[]  img={R.drawable.img,R.drawable.img1, R.drawable.img2,R.drawable.img4,R.drawable.img5,R.drawable.img6,R.drawable.img7,R.drawable.img8,R.drawable.img9,R.drawable.img10};
    private LayoutInflater inflater;
    private Context context;

    public CustomAdapter(Context context)
    {
        this.context=context;
    }

    public CustomAdapter(ImgViewPager imgViewPager) {

    }


    @Override
    public int getCount() {
        return img.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return (view==(LinearLayout)object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        //return super.instantiateItem(container, position);
    inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    View v=inflater.inflate(R.layout.swipe,container,false);

        ImageView imgs=(ImageView)v.findViewById(R.id.imgview);
        TextView tv=(TextView)v.findViewById(R.id.text1);
        imgs.setImageResource(img[position]);
        tv.setText("Image: "+position);

        container.addView(v);
        return v;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        //super.destroyItem(container, position, object);
      container.invalidate();

    }
}
