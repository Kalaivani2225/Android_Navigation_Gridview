package com.example.mahenth.thirdtask;


import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;



/**
 * A simple {@link Fragment} subclass.
 */
public class DisplayImagesGrid extends Fragment {

    RecyclerView recyclerView;
    MyCustomAdapter adaper;


   public DisplayImagesGrid() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

       getActivity().setTitle("GridView");
       View view=inflater.inflate(R.layout.fragment_display_images_grid, container, false);


        recyclerView = (RecyclerView)view.findViewById(R.id.recyclerview);

        adaper = new MyCustomAdapter(getContext(), DataSource.getData());
        //GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(),3);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false);

       //StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(3,StaggeredGridLayoutManager.HORIZONTAL);
       recyclerView.setLayoutManager(layoutManager);//staggeredGridLayoutManager);
        recyclerView.setAdapter(adaper);

        return view;

    }

}
