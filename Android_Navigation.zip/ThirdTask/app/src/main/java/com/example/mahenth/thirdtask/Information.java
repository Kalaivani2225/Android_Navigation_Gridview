package com.example.mahenth.thirdtask;

public class Information {
    public int imageId;
    public String title;
}
